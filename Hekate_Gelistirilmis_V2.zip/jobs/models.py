from django.db import models
from django.contrib.auth.models import User

class Job(models.Model):
    EMPLOYMENT_TYPES = (
        ('FT', 'Tam Zamanlı'),
        ('PT', 'Yarı Zamanlı'),
        ('RM', 'Uzaktan (Remote)'),
        ('HY', 'Hibrit'),
    )
    
    title = models.CharField(max_length=200, verbose_name="İş Unvanı")
    company_name = models.CharField(max_length=150, verbose_name="Şirket Adı", default="Hekate Şirketi")
    description = models.TextField(verbose_name="İş Açıklaması ve Gereksinimler")
    location = models.CharField(max_length=100, verbose_name="Lokasyon (Şehir/Ülke)")
    employment_type = models.CharField(max_length=2, choices=EMPLOYMENT_TYPES, default='FT', verbose_name="Çalışma Şekli")
    salary_range = models.CharField(max_length=100, blank=True, null=True, verbose_name="Maaş Aralığı (Opsiyonel)")
    
    is_active = models.BooleanField(default=True, verbose_name="İlan Aktif mi?")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "İş İlanı"
        verbose_name_plural = "İş İlanları"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} - {self.company_name}"

class Application(models.Model):
    STATUS_CHOICES = (
        ('NEW', 'Yeni Başvuru'),
        ('REV', 'İncelemede'),
        ('INT', 'Mülakat Aşamasında'),
        ('ACC', 'Kabul Edildi'),
        ('REJ', 'Reddedildi'),
    )
    
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='applications', verbose_name="İş İlanı")
    applicant = models.ForeignKey(User, on_delete=models.CASCADE, related_name='my_applications', verbose_name="Başvuran Aday")
    resume = models.FileField(upload_to='resumes/%Y/%m/', verbose_name="Özgeçmiş (CV)")
    cover_letter = models.TextField(blank=True, null=True, verbose_name="Ön Yazı")
    
    status = models.CharField(max_length=3, choices=STATUS_CHOICES, default='NEW', verbose_name="Başvuru Durumu")
    applied_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Başvuru"
        verbose_name_plural = "Başvurular"
        unique_together = ('job', 'applicant') # Bir kullanıcı bir ilana sadece bir kez başvurabilir.
        
    def __str__(self):
        return f"{self.applicant.username} -> {self.job.title} ({self.get_status_display()})"
