"""İK paketinin ortak dosyalara yaptığı 4 küçük eklemeyi otomatik yapar.
Proje klasöründe (manage.py'nin olduğu yer) çalıştırın:  python ik_kurulum.py
Birden fazla çalıştırmak zararsızdır."""
from pathlib import Path


def edit(path, marker, old=None, new=None, append=None):
    p = Path(path)
    if not p.exists():
        print('UYARI: dosya yok ->', path); return
    s = p.read_text(encoding='utf-8')
    if marker in s:
        print('zaten yapılmış ->', path); return
    if append is not None:
        s = s.rstrip('\n') + '\n' + append
    elif old in s:
        s = s.replace(old, new, 1)
    else:
        print('UYARI: elle yapılmalı ->', path, '(satır bulunamadı)'); return
    p.write_text(s, encoding='utf-8')
    print('güncellendi ->', path)


edit('accounts/urls.py', 'jobs.hr_views', 'from . import views\n', 'from jobs.hr_views import register_hr\nfrom . import views\n')
edit('accounts/urls.py', 'register_hr, name',
     "path('kayit/isveren/', views.register, {'role': 'hr'}, name='register_hr')",
     "path('kayit/isveren/', register_hr, name='register_hr')")
edit('hekate/settings.py', 'MEDIA_ROOT', append="\nMEDIA_URL = '/media/'\nMEDIA_ROOT = BASE_DIR / 'media'\n")
edit('hekate/urls.py', 'MEDIA_URL', append="\nfrom django.conf import settings\nfrom django.conf.urls.static import static\nurlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)\n")
edit('.gitignore', 'media/', append='media/\n')
