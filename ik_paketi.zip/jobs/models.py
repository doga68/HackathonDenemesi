from django.conf import settings
from django.core.validators import FileExtensionValidator
from django.db import models
from accounts.models import parse_skills

User = settings.AUTH_USER_MODEL


CITIES = [(c, c) for c in ['Girne', 'Lefkoşa', 'Gazimağusa', 'Güzelyurt', 'Lefke', 'İskele']]
BUSINESS_TYPES = [('otel', 'Otel'), ('restoran', 'Restoran'), ('kafe', 'Kafe'), ('tatil_koyu', 'Tatil köyü')]
DEPARTMENTS = [('servis', 'Servis'), ('mutfak', 'Mutfak'), ('on_buro', 'Ön büro'), ('kat', 'Kat hizmetleri')]
DISTRICTS = {  # şehir -> ilçe/bölge listesi (örnek, buradan düzenlenir)
    'Girne': ['Girne Merkez', 'Alsancak', 'Lapta', 'Çatalköy', 'Esentepe', 'Karaoğlanoğlu', 'Karşıyaka'],
    'Lefkoşa': ['Lefkoşa Merkez', 'Gönyeli', 'Hamitköy', 'Alayköy', 'Haspolat'],
    'Gazimağusa': ['Gazimağusa Merkez', 'Mormenekşe', 'Geçitkale', 'Tuzla', 'Akdoğan'],
    'Güzelyurt': ['Güzelyurt Merkez', 'Yeşilırmak', 'Zümrütköy', 'Gaziveren'],
    'Lefke': ['Lefke Merkez', 'Gemikonağı', 'Yeşilyurt'],
    'İskele': ['İskele Merkez', 'Boğaz', 'Yeni Erenköy', 'Bafra', 'Long Beach'],
}
EMPLOYMENT = [('full', 'Tam zamanlı'), ('part', 'Yarı zamanlı'), ('season', 'Sezonluk')]


class Job(models.Model):
    employer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='jobs')
    title = models.CharField('Pozisyon', max_length=100)
    description = models.TextField('Açıklama')
    location = models.CharField('Şehir', max_length=100, choices=CITIES, default='Girne')
    employment_type = models.CharField('Çalışma tipi', max_length=10, choices=EMPLOYMENT, default='full')
    openings = models.PositiveIntegerField('Kaç kişi aranıyor', default=1)
    min_experience = models.PositiveIntegerField('Minimum deneyim (yıl)', default=0)
    languages = models.CharField('Aranan diller (virgülle ayırın)', max_length=200, blank=True)
    department = models.CharField('Departman', max_length=10, choices=DEPARTMENTS, default='servis')
    salary_min = models.PositiveIntegerField('Maaş (en az)', null=True)
    salary_max = models.PositiveIntegerField('Maaş (en çok)', null=True)
    housing = models.BooleanField('Konaklama sağlanıyor mu?', default=False)
    meals = models.BooleanField('Yemek sağlanıyor mu?', default=False)
    start_date = models.DateField('İşe başlangıç tarihi', null=True)
    deadline = models.DateField('Son başvuru tarihi', null=True)
    required_skills = models.CharField('Aranan nitelikler (virgülle ayırın)', max_length=300)
    is_open = models.BooleanField('Açık', default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def match_percent(self, profile):
        req = parse_skills(self.required_skills)
        if not req:
            return 0
        return round(100 * len(req & parse_skills(profile.skills)) / len(req))


class Application(models.Model):
    STATUS = [('pending', 'Beklemede'), ('accepted', 'Kabul edildi'), ('rejected', 'Reddedildi')]
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='applications')
    applicant = models.ForeignKey(User, on_delete=models.CASCADE, related_name='applications')
    message = models.TextField('Ön yazı', blank=True)
    status = models.CharField(max_length=10, choices=STATUS, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('job', 'applicant')
        ordering = ['-created_at']


class Worker(models.Model):
    employer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='workers')
    full_name = models.CharField('Ad Soyad', max_length=100)
    position = models.CharField('Pozisyon', max_length=100)
    phone = models.CharField('Telefon', max_length=30, blank=True)

    def __str__(self):
        return self.full_name


class EmployerInfo(models.Model):
    """İK (işveren) kaydındaki işletme bilgileri. Yetkili adı/e-posta User'da, şirket adı/telefon Profile'da."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='employer_info')
    city = models.CharField('Şehir', max_length=50, choices=CITIES)
    district = models.CharField('İlçe / Bölge', max_length=60)
    business_type = models.CharField('İşletme türü', max_length=20, choices=BUSINESS_TYPES)
    address = models.CharField('Adres', max_length=255)
    website = models.URLField('Web sitesi')
    logo = models.FileField('Logo', upload_to='logos/',
                            validators=[FileExtensionValidator(['png', 'jpg', 'jpeg', 'webp'])])
    about = models.TextField('İşletme hakkında')

    def __str__(self):
        return f"{self.user.username} – {self.get_business_type_display()}"
