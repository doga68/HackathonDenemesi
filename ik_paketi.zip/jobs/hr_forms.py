"""İK (işveren) formları – İK backend sorumlusunun dosyası."""
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.validators import FileExtensionValidator

from .models import BUSINESS_TYPES, CITIES, DISTRICTS, Job

YES_NO = [(True, 'Evet'), (False, 'Hayır')]
JOB_FIELDS = ['title', 'department', 'description', 'location', 'employment_type', 'openings',
              'min_experience', 'languages', 'required_skills', 'salary_min', 'salary_max',
              'housing', 'meals', 'start_date', 'deadline']


class JobForm(forms.ModelForm):
    class Meta:
        model = Job
        fields = JOB_FIELDS
        widgets = {
            'housing': forms.RadioSelect(choices=YES_NO, attrs={'class': 'btn-check'}),
            'meals': forms.RadioSelect(choices=YES_NO, attrs={'class': 'btn-check'}),
            'start_date': forms.DateInput(format='%Y-%m-%d', attrs={'type': 'date'}),
            'deadline': forms.DateInput(format='%Y-%m-%d', attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 4}),
        }

    def clean(self):
        c = super().clean()
        lo, hi = c.get('salary_min'), c.get('salary_max')
        if lo is not None and hi is not None and lo > hi:
            self.add_error('salary_max', 'En çok maaş, en az maaştan küçük olamaz.')
        if c.get('deadline') and c.get('start_date') and c['deadline'] > c['start_date']:
            self.add_error('deadline', 'Son başvuru tarihi, işe başlangıç tarihinden sonra olamaz.')
        return c


class JobEditForm(JobForm):
    class Meta(JobForm.Meta):
        fields = JOB_FIELDS + ['is_open']


class HRRegisterForm(UserCreationForm):
    phone = forms.CharField(label='Telefon', max_length=30)
    company_name = forms.CharField(label='Otel / Şirket adı', max_length=100)
    city = forms.ChoiceField(label='Şehir', choices=CITIES)
    district = forms.ChoiceField(label='İlçe / Bölge',
                                 choices=[(d, d) for ds in DISTRICTS.values() for d in ds])
    business_type = forms.ChoiceField(label='İşletme türü', choices=BUSINESS_TYPES)
    address = forms.CharField(label='Adres', max_length=255)
    website = forms.URLField(label='Web sitesi (https://...)')
    logo = forms.FileField(label='Logo (png, jpg, webp – en fazla 2 MB)',
                           validators=[FileExtensionValidator(['png', 'jpg', 'jpeg', 'webp'])])
    about = forms.CharField(label='İşletme hakkında kısa yazı', max_length=1000,
                            widget=forms.Textarea(attrs={'rows': 3}))

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('first_name', 'last_name', 'username', 'email')

    field_order = ['first_name', 'last_name', 'username', 'email', 'phone', 'company_name', 'business_type',
                   'city', 'district', 'address', 'website', 'logo', 'about', 'password1', 'password2']

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        for name, label in (('first_name', 'Yetkili adı'), ('last_name', 'Yetkili soyadı'), ('email', 'E-posta')):
            self.fields[name].required = True
            self.fields[name].label = label

    def clean_logo(self):
        logo = self.cleaned_data['logo']
        if logo.size > 2 * 1024 * 1024:
            raise forms.ValidationError('Logo en fazla 2 MB olabilir.')
        return logo

    def clean(self):
        c = super().clean()
        if c.get('city') and c.get('district') and c['district'] not in DISTRICTS.get(c['city'], []):
            self.add_error('district', 'Seçilen ilçe bu şehre ait değil.')
        return c
