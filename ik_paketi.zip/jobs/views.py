from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from accounts.forms import ProfileForm
from .models import Application, Job

def role_required(role):
    def deco(view):
        @login_required
        @wraps(view)
        def wrapper(request, *a, **kw):
            p = getattr(request.user, 'profile', None)
            if not p or p.role != role:
                return redirect('home')
            return view(request, *a, **kw)
        return wrapper
    return deco


# ---------- İş arayan ----------
@role_required('seeker')
def job_list(request):
    profile = request.user.profile
    applied = set(request.user.applications.values_list('job_id', flat=True))
    rows = sorted(((j, j.match_percent(profile), j.pk in applied)
                   for j in Job.objects.filter(is_open=True)), key=lambda r: -r[1])
    return render(request, 'jobs/job_list.html', {'rows': rows})


@role_required('seeker')
def job_detail(request, pk):
    job = get_object_or_404(Job, pk=pk, is_open=True)
    existing = Application.objects.filter(job=job, applicant=request.user).first()
    if request.method == 'POST' and not existing:
        Application.objects.create(job=job, applicant=request.user, message=request.POST.get('message', ''))
        messages.success(request, 'Başvurunuz İK’ya iletildi.')
        return redirect('my_applications')
    return render(request, 'jobs/job_detail.html',
                  {'job': job, 'match': job.match_percent(request.user.profile), 'existing': existing})


@role_required('seeker')
def my_applications(request):
    return render(request, 'jobs/my_applications.html',
                  {'apps': request.user.applications.select_related('job')})


@role_required('seeker')
def profile(request):
    form = ProfileForm(request.POST or None, instance=request.user.profile)
    if form.is_valid():
        form.save()
        messages.success(request, 'Profil güncellendi.')
        return redirect('job_list')
    return render(request, 'form.html', {'form': form, 'title': 'Profilim'})
