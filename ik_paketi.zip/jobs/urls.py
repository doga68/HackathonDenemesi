from django.urls import path
from . import hr_views as h
from . import views as v

urlpatterns = [
    # İK (işveren) – hr_views.py
    path('isveren/', h.hr_dashboard, name='hr_dashboard'),
    path('isveren/ilan/yeni/', h.job_create, name='job_create'),
    path('isveren/ilan/<int:pk>/duzenle/', h.job_edit, name='job_edit'),
    path('isveren/ilan/<int:pk>/ac-kapat/', h.job_toggle, name='job_toggle'),
    path('isveren/ilan/<int:pk>/sil/', h.job_delete, name='job_delete'),
    path('isveren/ilan/<int:pk>/basvurular/', h.applicants, name='applicants'),
    path('isveren/basvuru/<int:pk>/', h.applicant_detail, name='applicant_detail'),
    path('isveren/basvuru/<int:pk>/<str:decision>/', h.decide, name='decide'),
    # İş arayan – views.py
    path('ilanlar/', v.job_list, name='job_list'),
    path('ilanlar/<int:pk>/', v.job_detail, name='job_detail'),
    path('basvurularim/', v.my_applications, name='my_applications'),
    path('profil/', v.profile, name='profile'),
]
