"""İK (işveren) tarafı – bu dosyayı İK backend sorumlusu yönetir."""
from django.contrib import messages
from django.contrib.auth import login
from django.db import transaction
from django.db.models import Count
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.models import Profile
from .hr_forms import HRRegisterForm, JobEditForm, JobForm
from .models import DISTRICTS, Application, EmployerInfo, Job
from .views import role_required


def register_hr(request):
    form = HRRegisterForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        c = form.cleaned_data
        with transaction.atomic():
            user = form.save()
            Profile.objects.create(user=user, role='hr', company_name=c['company_name'], phone=c['phone'])
            EmployerInfo.objects.create(
                user=user, city=c['city'], district=c['district'], business_type=c['business_type'],
                address=c['address'], website=c['website'], logo=c['logo'], about=c['about'])
        login(request, user)
        return redirect('home')
    return render(request, 'jobs/hr_form.html', {'form': form, 'title': 'İşveren (İK) Kaydı',
                                                 'button': 'Kayıt ol', 'districts': DISTRICTS})


@role_required('hr')
def hr_dashboard(request):
    jobs = request.user.jobs.annotate(n=Count('applications'))
    stats = {
        'jobs': jobs.count(),
        'open': jobs.filter(is_open=True).count(),
        'pending': Application.objects.filter(job__employer=request.user, status='pending').count(),
    }
    return render(request, 'jobs/hr_dashboard.html', {'jobs': jobs, 'stats': stats})


@role_required('hr')
def job_create(request):
    form = JobForm(request.POST or None)
    if form.is_valid():
        job = form.save(commit=False)
        job.employer = request.user
        job.save()
        messages.success(request, 'İlan yayınlandı.')
        return redirect('hr_dashboard')
    return render(request, 'jobs/hr_form.html', {'form': form, 'title': 'Yeni iş ilanı', 'button': 'Yayınla'})


@role_required('hr')
def job_edit(request, pk):
    job = get_object_or_404(Job, pk=pk, employer=request.user)
    form = JobEditForm(request.POST or None, instance=job)
    if form.is_valid():
        form.save()
        messages.success(request, 'İlan güncellendi.')
        return redirect('hr_dashboard')
    return render(request, 'jobs/hr_form.html', {'form': form, 'title': f'İlanı düzenle: {job.title}'})


@require_POST
@role_required('hr')
def job_toggle(request, pk):
    job = get_object_or_404(Job, pk=pk, employer=request.user)
    job.is_open = not job.is_open
    job.save()
    messages.success(request, 'İlan açıldı.' if job.is_open else 'İlan kapatıldı.')
    return redirect('hr_dashboard')


@require_POST
@role_required('hr')
def job_delete(request, pk):
    get_object_or_404(Job, pk=pk, employer=request.user).delete()
    messages.success(request, 'İlan silindi.')
    return redirect('hr_dashboard')


@role_required('hr')
def applicants(request, pk):
    job = get_object_or_404(Job, pk=pk, employer=request.user)
    apps = job.applications.select_related('applicant__profile')
    rows = sorted(((a, job.match_percent(a.applicant.profile)) for a in apps), key=lambda r: -r[1])
    return render(request, 'jobs/applicants.html', {'job': job, 'rows': rows})


@role_required('hr')
def applicant_detail(request, pk):
    app = get_object_or_404(Application.objects.select_related('job', 'applicant__profile'),
                            pk=pk, job__employer=request.user)
    return render(request, 'jobs/applicant_detail.html',
                  {'app': app, 'match': app.job.match_percent(app.applicant.profile)})


@require_POST
@role_required('hr')
def decide(request, pk, decision):
    app = get_object_or_404(Application, pk=pk, job__employer=request.user)
    if decision in ('accepted', 'rejected'):
        app.status = decision
        app.save()
        messages.success(request, 'Aday kabul edildi.' if decision == 'accepted' else 'Başvuru reddedildi.')
    return redirect('applicants', pk=app.job_id)
