from django import template

register = template.Library()


@register.filter
def chips(value):
    """'garson, almanca' -> ['garson', 'almanca']"""
    return [s.strip() for s in (value or '').split(',') if s.strip()]


FLOWS = {
    'hr': ['Kayıt', 'İlan aç', 'Başvuruları incele', 'Karar ver'],
    'seeker': ['Kayıt', 'Profil', 'İlan seç', 'Başvur', 'Sonuç'],
}


@register.filter
def flowsteps(role):
    return FLOWS.get(role, [])
