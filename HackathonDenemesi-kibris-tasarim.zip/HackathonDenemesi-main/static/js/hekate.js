(function () {
  var root = document.documentElement;
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: .12 });
  document.querySelectorAll('[data-reveal]').forEach(function (el) { io.observe(el); });
  var journeys = [].slice.call(document.querySelectorAll('.journey')), tick = false;
  function update() {
    tick = false;
    var max = root.scrollHeight - innerHeight;
    root.style.setProperty('--sy', max > 0 ? (scrollY / max).toFixed(3) : 0);
    journeys.forEach(function (j) {
      var r = j.getBoundingClientRect();
      var d = Math.min(1, Math.max(0, (innerHeight * .85 - r.top) / (r.height + innerHeight * .2)));
      j.style.setProperty('--draw', d.toFixed(3));
      var items = j.querySelectorAll('li');
      items.forEach(function (li, i) { li.classList.toggle('lit', d > (i + .4) / items.length * .9); });
    });
  }
  addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(update); } }, { passive: true });
  addEventListener('resize', update);
  update();
})();
