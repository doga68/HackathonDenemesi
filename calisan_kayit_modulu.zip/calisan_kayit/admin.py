from django.contrib import admin

from .models import CalisanProfili


@admin.register(CalisanProfili)
class CalisanProfiliAdmin(admin.ModelAdmin):
    list_display = ("kullanici", "telefon", "cv", "olusturulma")
