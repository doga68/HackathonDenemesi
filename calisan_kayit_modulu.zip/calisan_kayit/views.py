from django.conf import settings
from django.contrib.auth import get_user_model, login
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import redirect, render

from .forms import CalisanKayitFormu
from .models import CalisanProfili

User = get_user_model()


def _kayit_sonrasi_hedef():
    """
    Kayıttan sonra gidilecek sayfa. Ekip, settings.py içine şunu ekleyerek
    ilanlar sayfasını belirler (URL adı ya da yol olabilir):
        CALISAN_KAYIT_YONLENDIRME = "/"
    """
    return getattr(settings, "CALISAN_KAYIT_YONLENDIRME", "/")


def kayit(request):
    if request.user.is_authenticated:
        return redirect(_kayit_sonrasi_hedef())

    if request.method == "POST":
        form = CalisanKayitFormu(request.POST, request.FILES)
        if form.is_valid():
            d = form.cleaned_data
            with transaction.atomic():
                user = User.objects.create_user(
                    username=d["username"],
                    email=d["email"],
                    password=d["password1"],
                    first_name=d["first_name"],
                    last_name=d["last_name"],
                )
                CalisanProfili.objects.create(kullanici=user, telefon=d["telefon"], cv=d["cv"])
            login(request, user, backend="django.contrib.auth.backends.ModelBackend")
            return redirect(_kayit_sonrasi_hedef())
    else:
        form = CalisanKayitFormu()

    return render(request, "calisan_kayit/kayit.html", {"form": form})


@login_required
def profil(request):
    profil = getattr(request.user, "calisan_kayit_profili", None)
    return render(request, "calisan_kayit/profil.html", {"profil": profil})
