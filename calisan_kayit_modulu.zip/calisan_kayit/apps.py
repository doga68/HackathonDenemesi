from django.apps import AppConfig


class CalisanKayitConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "calisan_kayit"
    verbose_name = "Çalışan kayıt"
