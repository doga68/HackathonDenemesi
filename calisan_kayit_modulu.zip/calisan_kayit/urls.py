from django.urls import path

from . import views

app_name = "calisan_kayit"

urlpatterns = [
    path("kayit/", views.kayit, name="kayit"),
    path("profil/", views.profil, name="profil"),
]
