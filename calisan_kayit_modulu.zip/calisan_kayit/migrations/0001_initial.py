import django.core.validators
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models

import calisan_kayit.models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="CalisanProfili",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "telefon",
                    models.CharField(
                        max_length=16,
                        validators=[
                            django.core.validators.RegexValidator(
                                message="Telefon numarası 10-15 haneli olmalı (örn: 05551234567 veya +905551234567).",
                                regex="^\\+?\\d{10,15}$",
                            )
                        ],
                        verbose_name="Telefon numarası",
                    ),
                ),
                (
                    "cv",
                    models.FileField(
                        upload_to=calisan_kayit.models.cv_yolu,
                        validators=[django.core.validators.FileExtensionValidator(["pdf", "doc", "docx"])],
                        verbose_name="CV",
                    ),
                ),
                ("olusturulma", models.DateTimeField(auto_now_add=True)),
                (
                    "kullanici",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="calisan_kayit_profili",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "verbose_name": "Çalışan profili",
                "verbose_name_plural": "Çalışan profilleri",
            },
        ),
    ]
