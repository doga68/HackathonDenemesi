from django.conf import settings
from django.core.validators import FileExtensionValidator, RegexValidator
from django.db import models

telefon_dogrulayici = RegexValidator(
    regex=r"^\+?\d{10,15}$",
    message="Telefon numarası 10-15 haneli olmalı (örn: 05551234567 veya +905551234567).",
)


def cv_yolu(instance, filename):
    # media/cvler/<kullanici_id>/<dosya_adi>
    return f"cvler/{instance.kullanici_id}/{filename}"


class CalisanProfili(models.Model):
    """
    Projenin mevcut kullanıcı modeline (settings.AUTH_USER_MODEL) bağlanır.
    Yeni bir kullanıcı modeli TANIMLAMAZ, bu yüzden ekibin hesap sistemiyle çakışmaz.
    Ad, soyad, kullanıcı adı, e-posta ve şifre kullanıcı modelinde; telefon ve CV burada tutulur.
    """

    kullanici = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="calisan_kayit_profili",
    )
    telefon = models.CharField("Telefon numarası", max_length=16, validators=[telefon_dogrulayici])
    cv = models.FileField(
        "CV",
        upload_to=cv_yolu,
        validators=[FileExtensionValidator(["pdf", "doc", "docx"])],
    )
    olusturulma = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Çalışan profili"
        verbose_name_plural = "Çalışan profilleri"

    def __str__(self):
        return f"{self.kullanici.get_username()} - çalışan profili"
