# calisan_kayit – Çalışan kayıt modülü

Bu klasör, ekip projesine **tek başına eklenebilen** bir Django uygulamasıdır.
Yeni kullanıcı modeli tanımlamaz, `manage.py`, `settings.py`, `templates/` veya `requirements.txt` içermez;
bu yüzden ekibin hiçbir dosyasının üzerine yazmaz. Yeni paket de gerektirmez.

Kayıt formu: ad, soyad, kullanıcı adı, e-posta, telefon, şifre, şifre tekrarı, CV (PDF/DOC/DOCX, en çok 5 MB).
Ad/soyad/kullanıcı adı/e-posta/şifre projenin mevcut kullanıcı modeline, telefon ve CV `CalisanProfili` tablosuna kaydedilir.

## 1) GitHub'a yükleme
`calisan_kayit` klasörünü ana dizine (manage.py'nin yanına) olduğu gibi yükleyin.

## 2) settings.py (ayar dosyasında, 3 ekleme)
```python
INSTALLED_APPS = [
    # ... mevcutlar ...
    "calisan_kayit",
]

# CV dosyaları için (zaten varsa tekrar eklemeyin)
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

# Kayıttan sonra gidilecek sayfa (ilanlar sayfasının URL adı ya da yolu)
CALISAN_KAYIT_YONLENDIRME = "/"
```

## 3) Ana urls.py (2 ekleme)
```python
from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path

urlpatterns = [
    # ... mevcutlar ...
    path("calisan/", include("calisan_kayit.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

## 4) Veritabanı
```
python manage.py migrate
```
(Migration dosyası hazırdır. `makemigrations` çalıştırıp ayrı bir migration üretmeyin.)

## 5) Adresler
- /calisan/kayit/  → çalışan kayıt sayfası
- /calisan/profil/ → giriş yapmış çalışanın bilgileri ve CV bağlantısı

## Notlar
- `media/` klasörünü ve `db.sqlite3` dosyasını GitHub'a yüklemeyin (`.gitignore` içinde olmalı).
- Projede özel kullanıcı modeli varsa `username`, `email`, `first_name`, `last_name` alanları bulunmalı
  (Django'nun varsayılan User modelinde hepsi vardır).
