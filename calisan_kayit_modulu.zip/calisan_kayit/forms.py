from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.validators import FileExtensionValidator

from .models import telefon_dogrulayici

User = get_user_model()

MAX_CV_MB = 5


class CalisanKayitFormu(forms.Form):
    first_name = forms.CharField(label="Ad", max_length=150)
    last_name = forms.CharField(label="Soyad", max_length=150)
    username = forms.CharField(label="Kullanıcı adı", max_length=150)
    email = forms.EmailField(label="E-posta")
    telefon = forms.CharField(label="Telefon numarası", max_length=16)
    password1 = forms.CharField(label="Şifre", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Şifre (tekrar)", widget=forms.PasswordInput)
    cv = forms.FileField(
        label="CV yükle (PDF, DOC, DOCX)",
        validators=[FileExtensionValidator(["pdf", "doc", "docx"])],
    )

    def clean_username(self):
        username = self.cleaned_data["username"]
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("Bu kullanıcı adı zaten alınmış.")
        return username

    def clean_email(self):
        email = self.cleaned_data["email"].lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Bu e-posta ile zaten bir hesap var.")
        return email

    def clean_telefon(self):
        # Boşluk, tire ve parantezleri temizle
        telefon = "".join(c for c in self.cleaned_data["telefon"] if c.isdigit() or c == "+")
        telefon_dogrulayici(telefon)
        return telefon

    def clean_cv(self):
        cv = self.cleaned_data["cv"]
        if cv.size > MAX_CV_MB * 1024 * 1024:
            raise forms.ValidationError(f"CV dosyası en fazla {MAX_CV_MB} MB olabilir.")
        return cv

    def clean(self):
        data = super().clean()
        p1, p2 = data.get("password1"), data.get("password2")
        if p1 and p2:
            if p1 != p2:
                self.add_error("password2", "Şifreler eşleşmiyor.")
            else:
                try:
                    validate_password(
                        p1,
                        user=User(
                            username=data.get("username", ""),
                            first_name=data.get("first_name", ""),
                            last_name=data.get("last_name", ""),
                            email=data.get("email", ""),
                        ),
                    )
                except forms.ValidationError as e:
                    self.add_error("password1", e)
        return data
