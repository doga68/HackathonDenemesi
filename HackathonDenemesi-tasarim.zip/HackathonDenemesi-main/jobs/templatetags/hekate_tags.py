from django import template

register = template.Library()


@register.filter
def chips(value):
    """'garson, almanca' -> ['garson', 'almanca']"""
    return [s.strip() for s in (value or '').split(',') if s.strip()]
